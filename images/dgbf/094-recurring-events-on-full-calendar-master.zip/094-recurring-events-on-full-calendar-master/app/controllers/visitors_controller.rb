class VisitorsController < ApplicationController
  def index
  end
end
